package com.example.domain;

import lombok.Data;

@Data
public class RecommendVO {
	private int boardNum;
	private String id;
}
