package com.example.domain;

import lombok.Data;

@Data
public class TodaysRankVO {
	
	private int todaysRank;
	private String movieNum;
	private String reservationRate;
	
}
