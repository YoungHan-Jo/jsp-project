package com.example.domain;

import lombok.Data;

@Data
public class ScheduledMovieVO {
	private int scheduledRank;
	private String movieNum;
	private String dDay;
}
